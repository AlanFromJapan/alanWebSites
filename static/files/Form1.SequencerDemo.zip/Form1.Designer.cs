using Sanford.Multimedia.Midi;

namespace SequencerDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if(disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.stopButton = new System.Windows.Forms.Button();
            this.startButton = new System.Windows.Forms.Button();
            this.continueButton = new System.Windows.Forms.Button();
            this.positionHScrollBar = new System.Windows.Forms.HScrollBar();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mIDIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.outputDeviceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.copyAllOutputToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openMidiFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pianoControl1 = new Sanford.Multimedia.Midi.UI.PianoControl();
            this.sequence1 = new Sanford.Multimedia.Midi.Sequence();
            this.sequencer1 = new Sanford.Multimedia.Midi.Sequencer();
            this.txbOutput = new System.Windows.Forms.TextBox();
            this.grpVampParams = new System.Windows.Forms.GroupBox();
            this.txbVamp3 = new System.Windows.Forms.TextBox();
            this.txbVamp2 = new System.Windows.Forms.TextBox();
            this.txbVamp1 = new System.Windows.Forms.TextBox();
            this.ckbVamp3 = new System.Windows.Forms.CheckBox();
            this.ckbVamp2 = new System.Windows.Forms.CheckBox();
            this.ckbVamp1 = new System.Windows.Forms.CheckBox();
            this.ckbVampIncludeStops = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ckbVampExcludeSmallDelay = new System.Windows.Forms.CheckBox();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.grpVampParams.SuspendLayout();
            this.SuspendLayout();
            // 
            // stopButton
            // 
            this.stopButton.Location = new System.Drawing.Point(86, 73);
            this.stopButton.Name = "stopButton";
            this.stopButton.Size = new System.Drawing.Size(75, 21);
            this.stopButton.TabIndex = 0;
            this.stopButton.Text = "Stop";
            this.stopButton.UseVisualStyleBackColor = true;
            this.stopButton.Click += new System.EventHandler(this.stopButton_Click);
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(185, 73);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(75, 21);
            this.startButton.TabIndex = 1;
            this.startButton.Text = "Start";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // continueButton
            // 
            this.continueButton.Location = new System.Drawing.Point(286, 73);
            this.continueButton.Name = "continueButton";
            this.continueButton.Size = new System.Drawing.Size(75, 21);
            this.continueButton.TabIndex = 2;
            this.continueButton.Text = "Continue";
            this.continueButton.UseVisualStyleBackColor = true;
            this.continueButton.Click += new System.EventHandler(this.continueButton_Click);
            // 
            // positionHScrollBar
            // 
            this.positionHScrollBar.Location = new System.Drawing.Point(12, 42);
            this.positionHScrollBar.Name = "positionHScrollBar";
            this.positionHScrollBar.Size = new System.Drawing.Size(424, 17);
            this.positionHScrollBar.TabIndex = 3;
            this.positionHScrollBar.Scroll += new System.Windows.Forms.ScrollEventHandler(this.positionHScrollBar_Scroll);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.mIDIToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.toolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(448, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(36, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
            this.openToolStripMenuItem.Text = "&Open...";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(99, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // mIDIToolStripMenuItem
            // 
            this.mIDIToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.outputDeviceToolStripMenuItem});
            this.mIDIToolStripMenuItem.Name = "mIDIToolStripMenuItem";
            this.mIDIToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.mIDIToolStripMenuItem.Text = "&MIDI";
            // 
            // outputDeviceToolStripMenuItem
            // 
            this.outputDeviceToolStripMenuItem.Name = "outputDeviceToolStripMenuItem";
            this.outputDeviceToolStripMenuItem.Size = new System.Drawing.Size(149, 22);
            this.outputDeviceToolStripMenuItem.Text = "Output Device...";
            this.outputDeviceToolStripMenuItem.Click += new System.EventHandler(this.outputDeviceToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(106, 22);
            this.aboutToolStripMenuItem.Text = "&About...";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyAllOutputToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(117, 20);
            this.toolStripMenuItem1.Text = "Vampirization menu";
            // 
            // copyAllOutputToolStripMenuItem
            // 
            this.copyAllOutputToolStripMenuItem.Name = "copyAllOutputToolStripMenuItem";
            this.copyAllOutputToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.copyAllOutputToolStripMenuItem.Text = "Copy all output";
            this.copyAllOutputToolStripMenuItem.Click += new System.EventHandler(this.copyAllOutputToolStripMenuItem_Click);
            // 
            // openMidiFileDialog
            // 
            this.openMidiFileDialog.DefaultExt = "mid";
            this.openMidiFileDialog.Filter = "MIDI files|*.mid|All files|*.*";
            this.openMidiFileDialog.Title = "Open MIDI file";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripProgressBar1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 453);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(448, 22);
            this.statusStrip1.TabIndex = 6;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(100, 16);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pianoControl1
            // 
            this.pianoControl1.HighNoteID = 109;
            this.pianoControl1.Location = new System.Drawing.Point(12, 111);
            this.pianoControl1.LowNoteID = 21;
            this.pianoControl1.Name = "pianoControl1";
            this.pianoControl1.NoteOnColor = System.Drawing.Color.SkyBlue;
            this.pianoControl1.Size = new System.Drawing.Size(424, 44);
            this.pianoControl1.TabIndex = 5;
            this.pianoControl1.Text = "pianoControl1";
            this.pianoControl1.PianoKeyDown += new System.EventHandler<Sanford.Multimedia.Midi.UI.PianoKeyEventArgs>(this.pianoControl1_PianoKeyDown);
            this.pianoControl1.PianoKeyUp += new System.EventHandler<Sanford.Multimedia.Midi.UI.PianoKeyEventArgs>(this.pianoControl1_PianoKeyUp);
            // 
            // sequence1
            // 
            this.sequence1.Format = 1;
            // 
            // sequencer1
            // 
            this.sequencer1.Position = 0;
            this.sequencer1.Sequence = this.sequence1;
            this.sequencer1.PlayingCompleted += new System.EventHandler(this.HandlePlayingCompleted);
            this.sequencer1.ChannelMessagePlayed += new System.EventHandler<Sanford.Multimedia.Midi.ChannelMessageEventArgs>(this.HandleChannelMessagePlayed);
            this.sequencer1.Stopped += new System.EventHandler<Sanford.Multimedia.Midi.StoppedEventArgs>(this.HandleStopped);
            this.sequencer1.SysExMessagePlayed += new System.EventHandler<Sanford.Multimedia.Midi.SysExMessageEventArgs>(this.HandleSysExMessagePlayed);
            this.sequencer1.Chased += new System.EventHandler<Sanford.Multimedia.Midi.ChasedEventArgs>(this.HandleChased);
            // 
            // txbOutput
            // 
            this.txbOutput.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txbOutput.Location = new System.Drawing.Point(12, 311);
            this.txbOutput.MaxLength = 65535;
            this.txbOutput.Multiline = true;
            this.txbOutput.Name = "txbOutput";
            this.txbOutput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txbOutput.Size = new System.Drawing.Size(424, 139);
            this.txbOutput.TabIndex = 7;
            // 
            // grpVampParams
            // 
            this.grpVampParams.Controls.Add(this.ckbVampExcludeSmallDelay);
            this.grpVampParams.Controls.Add(this.label1);
            this.grpVampParams.Controls.Add(this.ckbVampIncludeStops);
            this.grpVampParams.Controls.Add(this.txbVamp3);
            this.grpVampParams.Controls.Add(this.txbVamp2);
            this.grpVampParams.Controls.Add(this.txbVamp1);
            this.grpVampParams.Controls.Add(this.ckbVamp3);
            this.grpVampParams.Controls.Add(this.ckbVamp2);
            this.grpVampParams.Controls.Add(this.ckbVamp1);
            this.grpVampParams.Location = new System.Drawing.Point(12, 161);
            this.grpVampParams.Name = "grpVampParams";
            this.grpVampParams.Size = new System.Drawing.Size(424, 144);
            this.grpVampParams.TabIndex = 8;
            this.grpVampParams.TabStop = false;
            this.grpVampParams.Text = "Vampirization params";
            // 
            // txbVamp3
            // 
            this.txbVamp3.Location = new System.Drawing.Point(132, 60);
            this.txbVamp3.MaxLength = 1;
            this.txbVamp3.Name = "txbVamp3";
            this.txbVamp3.Size = new System.Drawing.Size(26, 19);
            this.txbVamp3.TabIndex = 3;
            this.txbVamp3.Text = "C";
            this.txbVamp3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txbVamp3.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txbVamp2
            // 
            this.txbVamp2.Location = new System.Drawing.Point(132, 38);
            this.txbVamp2.MaxLength = 1;
            this.txbVamp2.Name = "txbVamp2";
            this.txbVamp2.Size = new System.Drawing.Size(26, 19);
            this.txbVamp2.TabIndex = 3;
            this.txbVamp2.Text = "B";
            this.txbVamp2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txbVamp2.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txbVamp1
            // 
            this.txbVamp1.Location = new System.Drawing.Point(132, 16);
            this.txbVamp1.MaxLength = 1;
            this.txbVamp1.Name = "txbVamp1";
            this.txbVamp1.Size = new System.Drawing.Size(26, 19);
            this.txbVamp1.TabIndex = 3;
            this.txbVamp1.Text = "A";
            this.txbVamp1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ckbVamp3
            // 
            this.ckbVamp3.AutoSize = true;
            this.ckbVamp3.Checked = true;
            this.ckbVamp3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckbVamp3.Location = new System.Drawing.Point(6, 62);
            this.ckbVamp3.Name = "ckbVamp3";
            this.ckbVamp3.Size = new System.Drawing.Size(120, 16);
            this.ckbVamp3.TabIndex = 2;
            this.ckbVamp3.Text = "Vamp channel 3 to";
            this.ckbVamp3.UseVisualStyleBackColor = true;
            // 
            // ckbVamp2
            // 
            this.ckbVamp2.AutoSize = true;
            this.ckbVamp2.Checked = true;
            this.ckbVamp2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckbVamp2.Location = new System.Drawing.Point(6, 40);
            this.ckbVamp2.Name = "ckbVamp2";
            this.ckbVamp2.Size = new System.Drawing.Size(120, 16);
            this.ckbVamp2.TabIndex = 1;
            this.ckbVamp2.Text = "Vamp channel 2 to";
            this.ckbVamp2.UseVisualStyleBackColor = true;
            // 
            // ckbVamp1
            // 
            this.ckbVamp1.AutoSize = true;
            this.ckbVamp1.Checked = true;
            this.ckbVamp1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckbVamp1.Location = new System.Drawing.Point(6, 18);
            this.ckbVamp1.Name = "ckbVamp1";
            this.ckbVamp1.Size = new System.Drawing.Size(120, 16);
            this.ckbVamp1.TabIndex = 0;
            this.ckbVamp1.Text = "Vamp channel 1 to";
            this.ckbVamp1.UseVisualStyleBackColor = true;
            // 
            // ckbVampIncludeStops
            // 
            this.ckbVampIncludeStops.AutoSize = true;
            this.ckbVampIncludeStops.Checked = true;
            this.ckbVampIncludeStops.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckbVampIncludeStops.Location = new System.Drawing.Point(238, 16);
            this.ckbVampIncludeStops.Name = "ckbVampIncludeStops";
            this.ckbVampIncludeStops.Size = new System.Drawing.Size(92, 16);
            this.ckbVampIncludeStops.TabIndex = 4;
            this.ckbVampIncludeStops.Text = "Include stops";
            this.ckbVampIncludeStops.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label1.Location = new System.Drawing.Point(236, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 11);
            this.label1.TabIndex = 5;
            this.label1.Text = "(sometimes sounds better without)";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // ckbVampExcludeSmallDelay
            // 
            this.ckbVampExcludeSmallDelay.AutoSize = true;
            this.ckbVampExcludeSmallDelay.Location = new System.Drawing.Point(238, 60);
            this.ckbVampExcludeSmallDelay.Name = "ckbVampExcludeSmallDelay";
            this.ckbVampExcludeSmallDelay.Size = new System.Drawing.Size(126, 16);
            this.ckbVampExcludeSmallDelay.TabIndex = 6;
            this.ckbVampExcludeSmallDelay.Text = "Exclude small delay";
            this.ckbVampExcludeSmallDelay.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(448, 475);
            this.Controls.Add(this.grpVampParams);
            this.Controls.Add(this.txbOutput);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.pianoControl1);
            this.Controls.Add(this.positionHScrollBar);
            this.Controls.Add(this.continueButton);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.stopButton);
            this.Controls.Add(this.menuStrip1);
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Sequencer Demo";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.grpVampParams.ResumeLayout(false);
            this.grpVampParams.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button stopButton;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Button continueButton;
        private System.Windows.Forms.HScrollBar positionHScrollBar;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog openMidiFileDialog;
        private Sanford.Multimedia.Midi.UI.PianoControl pianoControl1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.ToolStripMenuItem mIDIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem outputDeviceToolStripMenuItem;
        private Sequence sequence1;
        private Sequencer sequencer1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox txbOutput;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem copyAllOutputToolStripMenuItem;
        private System.Windows.Forms.GroupBox grpVampParams;
        private System.Windows.Forms.CheckBox ckbVamp3;
        private System.Windows.Forms.CheckBox ckbVamp2;
        private System.Windows.Forms.CheckBox ckbVamp1;
        private System.Windows.Forms.TextBox txbVamp2;
        private System.Windows.Forms.TextBox txbVamp1;
        private System.Windows.Forms.TextBox txbVamp3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox ckbVampIncludeStops;
        private System.Windows.Forms.CheckBox ckbVampExcludeSmallDelay;
    }
}

